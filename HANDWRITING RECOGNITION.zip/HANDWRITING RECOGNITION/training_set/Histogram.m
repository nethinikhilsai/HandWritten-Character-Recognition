I=imread('D:\Cryptography\Decrypt.jpg');
imhist(I);