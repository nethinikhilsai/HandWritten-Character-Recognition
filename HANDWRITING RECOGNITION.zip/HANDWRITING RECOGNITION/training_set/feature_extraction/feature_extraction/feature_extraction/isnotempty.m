function result=isnotempty(matrix)
if isempty(matrix)
    result=0;
else
    result=1;
end