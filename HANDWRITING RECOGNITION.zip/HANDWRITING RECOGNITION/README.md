# HWCR
Handwritten Character Recognition System using Neural Networks developed using MATLAB Neural Network and Image Processing tool box. This system has been developed using existing algorithms like Preprocessing and Feature Extraction techniques.

For More Info http://www.slideshare.net/chiranjeeviadi/hand-written-character-recognition-using-neural-networks
